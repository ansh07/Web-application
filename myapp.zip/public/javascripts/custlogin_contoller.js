app.controller("custlogin_contoller",function($scope,$http){
  console.log("custlogin_contoller");


  $scope.submit_registation = function()
  {
      $scope.name_msg = ""
      $scope.passwd_msg = ""
      $scope.msg = ""
    console.log("++",$scope.sk.password);

    if ($scope.sk.password === $scope.sk.reenter_password) {
      $scope.passwd_msg = ""

    }else {
      $scope.passwd_msg = "Re-enter password"
    }
    if ($scope.sk.first_name === undefined || $scope.sk.first_name === "") {
      $scope.name_msg = " Enter the first name"
    }else {
      $scope.name_msg = ""

    }
      if ($scope.passwd_msg === "" && $scope.name_msg === "" ) {
        $http({
          url : urls+"custregistration",
          method : "POST",
          headers : {"content-type":"application/json"},
          data : $scope.sk
        }).then(function(response){
          console.log("response",response)
          if(response.data.status === false)
          {
            $scope.msg = "Email already exist"

          }else {
            $scope.msg = "Registration successfully"
            $scope.sk = undefined
          }

        },function(error){
          console.log("error",error);

        })
      }


  }


  $scope.msg1 = ""
  $scope.login_data = function()
  {
    console.log("---",$scope.login);
    $scope.msg = ""
    $http({
      url : urls+"userlogin",
      method : "POST",
      headers : {"content-type":"application/json"},
      data : $scope.login
    }).then(function(response){
      console.log("response",response.data.data)
      if(response.data.status === false)
      {
        $scope.msg1 = "invalid UserName and password"

      }else {
        if (response.data.data === "shopkeeper") {
          // $scope.msg1 = "Login successfully"
          window.location.href = "#/" // same page
        // window.open("https://www.google.com") //new tab
          // window.location.href = "https://www.google.com"

        }else {
          // window.open("https://www.google.com") //new tab
          window.location.href="http://localhost:3333/cart.html";


        }

      }

    },function(error){
      console.log("error",error);

    })

  }

})
