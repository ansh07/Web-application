app.controller("skcloginontroller",function($scope,$http,$location){
  console.log("skcloginontroller");
        $scope.submit_registation = function()
        {
          console.log("++",$scope.sk);

          $scope.msg = ""
          $http({
            url : "http://localhost:3333/skregistration",
            method : "POST",
            headers : {"content-type":"application/json"},
            data : $scope.sk
          }).then(function(response){
            console.log("response",response.data.status)
            if(response.data.status === false)
            {
              $scope.msg = "Email already exist"

            }else {
              $scope.msg = "Registration successfully"
              $scope.sk = undefined
            }

          },function(error){
            console.log("error",error);

          })

        }

        $scope.msg1 = ""
        $scope.login_data = function()
        {
          console.log("---",$scope.login);
          $scope.msg = ""
          $http({
            url : urls+"userlogin",
            method : "POST",
            headers : {"content-type":"application/json"},
            data : $scope.login
          }).then(function(response){
            console.log("response",response.data.data)
            if(response.data.status === false)
            {
              $scope.msg1 = "invalid UserName and password"

            }else {
              if (response.data.data === "shopkeeper") {
                // $scope.msg1 = "Login successfully"
                window.location.href = "#/" // same page
              // window.open("https://www.google.com") //new tab
                // window.location.href = "https://www.google.com"

              }else {
                // window.open("https://www.google.com") //new tab
                window.location.href="http://localhost:3333/cart.html";

              }

            }

          },function(error){
            console.log("error",error);

          })

        }

})
